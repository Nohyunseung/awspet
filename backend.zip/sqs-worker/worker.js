require('dotenv').config()
const { SQSClient, ReceiveMessageCommand, DeleteMessageCommand } = require('@aws-sdk/client-sqs')
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3')
const { RekognitionClient, DetectLabelsCommand } = require('@aws-sdk/client-rekognition')

// AWS 클라이언트 설정
const sqsClient = new SQSClient({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  }
})

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  }
})

const rekognitionClient = new RekognitionClient({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  }
})

console.log('🚀 SQS 워커 시작됨')
console.log('📍 큐 URL:', process.env.SQS_QUEUE_URL)
console.log('🪣 S3 버킷:', process.env.S3_BUCKET)

// 이미지 처리 함수
async function processImage(bucket, key) {
  try {
    console.log(`🖼️  이미지 처리 시작: s3://${bucket}/${key}`)
    
    // AWS Rekognition으로 이미지 분석
    const rekognitionParams = {
      Image: {
        S3Object: {
          Bucket: bucket,
          Name: key
        }
      },
      MaxLabels: 10,
      MinConfidence: 75
    }

    const rekognitionResult = await rekognitionClient.send(new DetectLabelsCommand(rekognitionParams))
    
    console.log('🔍 Rekognition 분석 결과:')
    rekognitionResult.Labels?.forEach(label => {
      console.log(`  - ${label.Name}: ${label.Confidence.toFixed(2)}%`)
    })

    // 강아지 관련 라벨 찾기
    const dogLabels = rekognitionResult.Labels?.filter(label => 
      ['Dog', 'Pet', 'Animal', 'Mammal', 'Canine'].includes(label.Name)
    ) || []

    if (dogLabels.length > 0) {
      console.log('🐕 강아지 관련 이미지로 확인됨!')
      
      // 여기에 추가 처리 로직을 넣을 수 있습니다:
      // - 데이터베이스에 분석 결과 저장
      // - 사용자에게 알림 전송
      // - 썸네일 생성
      // - 품종 분석 등
      
      return {
        success: true,
        isDog: true,
        labels: dogLabels,
        allLabels: rekognitionResult.Labels
      }
    } else {
      console.log('❓ 강아지가 아닌 것 같습니다')
      return {
        success: true,
        isDog: false,
        labels: [],
        allLabels: rekognitionResult.Labels
      }
    }

  } catch (error) {
    console.error('❌ 이미지 처리 실패:', error)
    return {
      success: false,
      error: error.message
    }
  }
}

// SQS 메시지 처리 함수
async function processMessage(message) {
  try {
    const body = JSON.parse(message.Body)
    console.log('📨 SQS 메시지 받음:', JSON.stringify(body, null, 2))
    
    // S3 이벤트 메시지 파싱
    if (body.Records && body.Records.length > 0) {
      for (const record of body.Records) {
        if (record.s3) {
          const bucket = record.s3.bucket.name
          const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '))
          
          console.log(`🔄 처리 중: ${bucket}/${key}`)
          
          // 이미지 처리
          const result = await processImage(bucket, key)
          
          if (result.success) {
            console.log('✅ 이미지 처리 완료')
          } else {
            console.log('❌ 이미지 처리 실패:', result.error)
          }
        }
      }
    }
    
    // 메시지 처리 완료 후 삭제
    const deleteParams = {
      QueueUrl: process.env.SQS_QUEUE_URL,
      ReceiptHandle: message.ReceiptHandle
    }
    
    await sqsClient.send(new DeleteMessageCommand(deleteParams))
    console.log('🗑️  SQS 메시지 삭제 완료')
    
  } catch (error) {
    console.error('❌ 메시지 처리 실패:', error)
  }
}

// SQS 폴링 루프
async function pollSQS() {
  while (true) {
    try {
      console.log('🔍 SQS 메시지 폴링 중...')
      
      const receiveParams = {
        QueueUrl: process.env.SQS_QUEUE_URL,
        MaxNumberOfMessages: 1,
        WaitTimeSeconds: 20, // Long polling (20초 대기)
        VisibilityTimeoutSeconds: 300 // 5분 동안 다른 워커가 같은 메시지 처리 안 함
      }
      
      const result = await sqsClient.send(new ReceiveMessageCommand(receiveParams))
      
      if (result.Messages && result.Messages.length > 0) {
        for (const message of result.Messages) {
          await processMessage(message)
        }
      } else {
        console.log('📭 새로운 메시지가 없습니다')
      }
      
    } catch (error) {
      console.error('❌ SQS 폴링 에러:', error)
      // 에러 발생 시 5초 대기 후 재시도
      await new Promise(resolve => setTimeout(resolve, 5000))
    }
  }
}

// 워커 시작
pollSQS().catch(console.error)